package ITC_Dhanush_javapackage;
import java.util.ArrayList;

public class Arrlist {
	public static void main(String[] args) {
	
	ArrayList<String> city=new ArrayList<String>();  
	
	city.add("delhi"); 
	city.add("bengalur");
	city.add("salem");
	city.add("chennai");
    
    System.out.println(city);
    
    
	}
}

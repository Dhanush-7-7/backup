package ITC_Dhanush_javapackage;

import java.util.ArrayList;
import java.util.List;

public class javacollections {
    public static void main(String[] args) {
        List<Department> departments = new ArrayList<>();
        
        departments.add(new Department("Sales", 50000, 20000));
        departments.add(new Department("Marketing", 40000, 15000));
        departments.add(new Department("R and D", 80000, 40000));
        
        for (Department dept : departments) {
            System.out.println(dept.getName() + " - Profit: " + dept.getProfit());
        }
        
        departments.sort((dept1, dept2) -> Double.compare(dept2.getProfit(), dept1.getProfit()));
        
        System.out.println("\nDepartments sorted by profit (Descending):");
        for (Department dept : departments) {
            System.out.println(dept.getName() + " - Profit: " + dept.getProfit());
        }
    }
    
    static class Department {
        private String name;
        private double sales;
        private double expenses;
        
        public Department(String name, double sales, double expenses) {
            this.name = name;
            this.sales = sales;
            this.expenses = expenses;
        }
        
        public double getProfit() {
            return sales - expenses;
        }
        
        public String getName() {
            return name;
        }
    }
}

package ITC_Dhanush_javapackage;
import java.io.*;

public class Filecheck {
    public static void main(String[] args) {
        String filePath = "/home/zadmin/Desktop/test/java.txt"; 
        File file = new File(filePath);

        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                System.out.println("File exists.");

                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }    

              
                   
            } 
               
               catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("File does not exist.");
        }
    }
}

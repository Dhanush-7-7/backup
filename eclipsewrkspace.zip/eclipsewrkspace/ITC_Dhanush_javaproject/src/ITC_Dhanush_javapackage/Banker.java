package ITC_Dhanush_javapackage;

import java.util.Scanner;

public class Banker {
    
    private double balance;
    private int accountNumber; 
    public Banker(int accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }
    
    public void checkBalance() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Current balance: rupees" + balance);
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: rupees" + amount);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
        } else if (amount > balance) {
            System.out.println("Insufficient balance.");
        } else {
            System.out.println("Withdrawal amount must be positive.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double initialBalance = 0;
        boolean validInput = false;
        
        while (!validInput) {
            System.out.print("Enter initial balance: Rs");
            if (scanner.hasNextDouble()) {
                initialBalance = scanner.nextDouble();
                validInput = true;
            } else {
                System.out.println("Please enter a valid number for the initial balance.");
                scanner.next();  
            }
        }

        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();

        Banker account = new Banker(accountNumber, initialBalance);

        while (true) {
            System.out.println("\nWelcome to Banking");
            System.out.println("Choose an option:");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Exit");

            int choice = 0;
            boolean validChoice = false;

            while (!validChoice) {
                if (scanner.hasNextInt()) {
                    choice = scanner.nextInt();
                    validChoice = true;
                } else {
                    System.out.println("Invalid choice. Please enter a number between 1 and 4.");
                    scanner.next();  
                }
            }

            switch (choice) {
                case 1:
                    account.checkBalance();
                    break;
                case 2:
                    double depositAmount = 0;
                    validInput = false;
                    while (!validInput) {
                        System.out.print("Enter deposit amount: ");
                        if (scanner.hasNextDouble()) {
                            depositAmount = scanner.nextDouble();
                            if (depositAmount > 0) {
                                account.deposit(depositAmount);
                                validInput = true;
                            } else {
                                System.out.println("Deposit amount must be positive.");
                            }
                        } else {
                            System.out.println("Please enter a valid number for deposit.");
                            scanner.next();  
                        }
                    }
                    break;
                case 3:
                    double withdrawAmount = 0;
                    validInput = false;
                    while (!validInput) {
                        System.out.print("Enter withdrawal amount: ");
                        if (scanner.hasNextDouble()) {
                            withdrawAmount = scanner.nextDouble();
                            if (withdrawAmount > 0) {
                                account.withdraw(withdrawAmount);
                                validInput = true;
                            } else {
                                System.out.println("Withdrawal amount must be positive.");
                            }
                        } else {
                            System.out.println("Please enter a valid number for withdrawal.");
                            scanner.next(); 
                        }
                    }
                    break;
                case 4:
                    System.out.println("thanks you for banking ");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}

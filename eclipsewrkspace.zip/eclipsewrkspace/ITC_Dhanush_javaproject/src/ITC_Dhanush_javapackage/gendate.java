package ITC_Dhanush_javapackage;
import java.util.*;
//import java.text.SimpleDateFormat;

public class gendate {
	public static void main(String[] args) {
		
		Calendar cp=Calendar.getInstance();
		cp.setTimeZone(TimeZone.getTimeZone("IST"));
		System.out.println(cp.get(Calendar.HOUR_OF_DAY));
		System.out.println(cp.get(Calendar.MINUTE));
		System.out.println(cp.get(Calendar.SECOND));

	
		
	}

}

package ITC_Dhanush_javapackage;
import java.util.Arrays;

public class Array {
	public static void main(String[] args) {
		
		int a[] = {2,8,4,6,7};
		Arrays.sort(a);
		System.out.println(Arrays.toString(a));
		
		
	}
	

}

package ITC_Dhanush_javapackage;

import java.util.*;

public class emporg {

    
    static class Employee {
        String name;
        String gender;
        String department;

        public Employee(String name, String gender, String department) {
            this.name = name;
            this.gender = gender;
            this.department = department;
        }

        
        public String getName() {
            return name;
        }

        public String getGender() {
            return gender;
        }

        public String getDepartment() {
            return department;
        }
    }

    public static void main(String[] args) {
        
        List<Employee> employeeList = new ArrayList<>();
        employeeList.add(new Employee("praveena", "Female", "HR"));
        employeeList.add(new Employee("lokesh", "Male", "Engineering"));
        employeeList.add(new Employee("santhosh", "Male", "Engineering"));
        employeeList.add(new Employee("sriram", "Male", "Data science"));
        
        
        int maleCount = 0, femaleCount = 0;
        
        for (Employee emp : employeeList) {
            if (emp.getGender().equalsIgnoreCase("Male")) {
                maleCount++;
            } else if (emp.getGender().equalsIgnoreCase("Female")) {
                femaleCount++;
            }
        }

       
        System.out.println("Male Employees: " + maleCount);
        System.out.println("Female Employees: " + femaleCount);
        
       
        Set<String> departments = new HashSet<>();
        for (Employee emp : employeeList) {
            departments.add(emp.getDepartment());
        }
        
       
        System.out.println("Departments in the Organization:");
        for (String dept : departments) {
            System.out.println(dept);
        }
    }
}

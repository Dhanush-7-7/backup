package ITC_Dhanush_javapackage;

class CreditcardPayment implements PaymentGateway{
	@Override
	public void Procespayment(double amount) {
		System.out.println("processing credit card payment of "+amount);
	}
}

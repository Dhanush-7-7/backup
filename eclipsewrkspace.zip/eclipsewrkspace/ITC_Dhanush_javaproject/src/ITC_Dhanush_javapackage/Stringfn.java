package ITC_Dhanush_javapackage;

public class Stringfn {
    public static void main(String[] args) {
        String str = "   I am ITC infotitan   ";

        System.out.println("Length: " + str.length());
        System.out.println("Character at index 7: " + str.charAt(7));
        System.out.println("Substring from index 5 to 16: " + str.substring(5, 16));
        System.out.println("Lowercase: " + str.toLowerCase());
        System.out.println("Uppercase: " + str.toUpperCase());
        System.out.println("Equals '   I am ITC infotitan   ' : " + str.equals("   I am ITC infotitan   "));
        System.out.println("Equals ignoring case '   i am itc infotitan   ' : " + str.equalsIgnoreCase("   i am itc infotitan   "));
        System.out.println("Trimmed: '" + str.trim() + "'");
        System.out.println("Replace 'ITC infotitan' with 'ITC infotech': " + str.replace("ITC infotitan", "ITC infotech"));
        System.out.println("Contains 'infotitan': " + str.contains("infotitan"));
        System.out.println("Index of 'ITC': " + str.indexOf("ITC"));
        
        String[] words = str.split(" ");
        System.out.println("Split words:");
        for (String word : words) {
            System.out.println(word);
        }

        System.out.println("Starts with '   I': " + str.startsWith("   I"));
        
        
        System.out.println("Ends with 'infotitan   ' : " + str.endsWith("infotitan   "));
        
        
        
        int number = 100;
        System.out.println("Value of number 100: " + String.valueOf(number));
    }
}

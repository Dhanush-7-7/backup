package ITC_Dhanush_javapackage;

public class test {
	
	public static void main(String[] args) {
		
		int a =25;
		int b = 75;

		System.out.println(a+b);
	}

}

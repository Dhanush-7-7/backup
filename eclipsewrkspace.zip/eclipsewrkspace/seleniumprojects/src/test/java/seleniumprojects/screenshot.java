package seleniumprojects;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;

public class screenshot {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        String screenshotDirectory = "/home/zadmin/screenshot/screenshots/";  
        String reportDirectory = "/home/zadmin/screenshot/reports/";  

        new File(screenshotDirectory).mkdirs();
        new File(reportDirectory).mkdirs();

        try (FileWriter reportWriter = new FileWriter(reportDirectory + "test_report.html")) {
            reportWriter.write("<html>\n<head>\n<title>Test Automation Report</title>\n</head>\n<body>\n");
            reportWriter.write("<h1>Test Automation Report</h1>\n");

            driver.get("https://practicetestautomation.com/");
            takeScreenshot(driver, screenshotDirectory, "launch_page.png");
            reportWriter.write("<p>Launched the page and took screenshot: <a href='screenshots/launch_page.png'>launch_page.png</a></p>\n");

            WebElement practiceLink = driver.findElement(By.xpath("//a[text()='Practice']"));
            practiceLink.click();
            takeScreenshot(driver, screenshotDirectory, "practice_page.png");
            reportWriter.write("<p>Clicked the 'Practice' link and took screenshot: <a href='screenshots/practice_page.png'>practice_page.png</a></p>\n");

            WebElement loginLink = driver.findElement(By.xpath("//a[text()='Test Login Page']"));
            loginLink.click();
            takeScreenshot(driver, screenshotDirectory, "login_page.png");
            reportWriter.write("<p>Clicked the 'Test Login' link and took screenshot: <a href='screenshots/login_page.png'>login_page.png</a></p>\n");

            WebElement usernameField = driver.findElement(By.xpath("//input[@id='username']"));
            usernameField.sendKeys("student");
            takeScreenshot(driver, screenshotDirectory, "typed_username.png");
            reportWriter.write("<p>Typed 'student' in the username field and took screenshot: <a href='screenshots/typed_username.png'>typed_username.png</a></p>\n");

            WebElement passwordField = driver.findElement(By.xpath("//input[@id='password']"));
            passwordField.sendKeys("Password123");
            takeScreenshot(driver, screenshotDirectory, "typed_password.png");
            reportWriter.write("<p>Typed password and took screenshot: <a href='screenshots/typed_password.png'>typed_password.png</a></p>\n");

            WebElement loginButton = driver.findElement(By.xpath("//*[@id='submit']"));
            loginButton.click();
            takeScreenshot(driver, screenshotDirectory, "after_login.png");
            reportWriter.write("<p>Clicked the login button and took screenshot: <a href='screenshots/after_login.png'>after_login.png</a></p>\n");

            driver.quit();
            reportWriter.write("<p>Driver closed.</p>\n");

            reportWriter.write("</body>\n</html>\n");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void takeScreenshot(WebDriver driver, String screenshotDirectory, String screenshotName) {
        TakesScreenshot screenshot = (TakesScreenshot) driver;
        File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
        File destFile = new File(screenshotDirectory + screenshotName);
        try {
            FileUtils.copyFile(srcFile, destFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

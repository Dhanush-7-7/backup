package seleniumprojects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class logintest {

    public static void main(String[] args) {

        ChromeOptions options = new ChromeOptions();

        WebDriver driver = new ChromeDriver(options);

        try {
            driver.get("https://practicetestautomation.com/practice-test-login/");

            driver.manage().window().maximize();

            WebElement usernameField = driver.findElement(By.id("username"));
            usernameField.sendKeys("student");

            WebElement passwordField = driver.findElement(By.id("password"));
            passwordField.sendKeys("Password123");

            WebElement loginButton = driver.findElement(By.id("submit"));
            loginButton.click();

           
            boolean loginSuccess = false;
            try {
                WebElement logoutButton = driver.findElement(By.linkText("Log out"));
                loginSuccess = logoutButton.isDisplayed();  
            } catch (Exception e) {
                loginSuccess = false;
            }

            if (loginSuccess) {
                System.out.println("Login successful!");
            } else {
                System.out.println("Login failed!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //driver.quit();
        }
    }
}

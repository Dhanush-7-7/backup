package seleniumprojects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.concurrent.TimeUnit;

public class WebshopAutomation {

    public static void main(String[] args) {
        // Set up the ChromeDriver path (change path if needed)
    //    System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        // Set up Chrome options for headless operation (optional)
        ChromeOptions options = new ChromeOptions();
     //   options.addArguments("--headless");  // This makes it run without opening the browser

        // Initialize the WebDriver
        WebDriver driver = new ChromeDriver(options);

        try {
            // Step 1: Navigate to the demo webshop
            driver.get("https://demowebshop.tricentis.com/");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

            // Step 2: Perform a login action (example with incorrect credentials)
            driver.findElement(By.linkText("Log in")).click();
            driver.findElement(By.id("Email")).sendKeys("incorrect@example.com");
            driver.findElement(By.id("Password")).sendKeys("password123");
            driver.findElement(By.cssSelector("input[value='Log in']")).click();

            // Step 3: Search for a product (e.g., "Apple")
            WebElement searchBox = driver.findElement(By.id("q"));
            searchBox.sendKeys("Apple");
            searchBox.submit();

            // Step 4: Add a product to the cart (example: first product from search results)
            WebElement product = driver.findElement(By.xpath("//div[@class='product-item'][1]"));
            product.click();
            driver.findElement(By.id("add-to-cart-button-4")).click();  // Add to cart button for the product

            // Step 5: Go to the shopping cart
            driver.findElement(By.className("cart-label")).click();

            // Step 6: Proceed to checkout or perform further actions like logging out
            // driver.findElement(By.className("checkout")).click();

            // Optional: Validate that the item is added to the cart (check if cart shows the item)
            WebElement cartItem = driver.findElement(By.cssSelector(".cart-item-row"));
            if (cartItem.isDisplayed()) {
                System.out.println("Product added to cart successfully!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Step 7: Close the browser
            driver.quit();
        }
    }
}

package seleniumprojects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Automation {
	
	public static void main(String[] args) {
		
		
		WebDriver driver =new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://practicetestautomation.com/");

		driver.findElement(By.xpath("//a[text()='Practice']")).click();

		driver.findElement(By.xpath("//a[text()='Test Login Page']")).click();
		
		 WebElement usernameField = driver.findElement(By.xpath("//input[@id='username']")); 
	        usernameField.sendKeys("student");
	        
	        WebElement passwordField = driver.findElement(By.xpath("//input[@id='password']")); 
	        passwordField.sendKeys("Password123");
	        
	        WebElement loginButton = driver.findElement(By.xpath("//button[@id='submit']")); 
	        loginButton.click();

	        
	    	driver.findElement(By.xpath("//a[text()='Log out']")).click();
	      

		
		driver.quit();
		
		
		
		
	}
	

}

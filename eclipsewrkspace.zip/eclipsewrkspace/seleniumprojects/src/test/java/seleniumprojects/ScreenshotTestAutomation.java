package seleniumprojects;

import java.io.*;
import java.nio.file.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ScreenshotTestAutomation {

    WebDriver driver;
    
    // Define the folder paths for screenshots and reports
    private static final String SCREENSHOT_FOLDER = "C:\\Users\\direc\\OneDrive\\Desktop\\CorporateTraining\\ITC\\Screenshots\\";
    private static final String REPORT_FOLDER = "C:\\Users\\direc\\OneDrive\\Desktop\\CorporateTraining\\ITC\\TestReports\\";

    // The report content will be stored here
    private StringBuilder reportContent = new StringBuilder();

    @BeforeMethod
    public void setUp() throws Exception {
        try {
            // Set the path to the WebDriver executable
            String driverPath = System.getProperty("webdriver.chrome.driver", "C:\\Users\\direc\\OneDrive\\Desktop\\CorporateTraining\\ITC\\chromedriver-win64\\chromedriver.exe");
            System.setProperty("webdriver.chrome.driver", driverPath);

            // Initialize WebDriver (using Chrome in this example)
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            
            // Ensure the screenshot and report folders exist
            Files.createDirectories(Paths.get(SCREENSHOT_FOLDER));
            Files.createDirectories(Paths.get(REPORT_FOLDER));

            // Initialize HTML report structure
            reportContent.append("<html><head><title>Test Automation Report</title></head><body>");
            reportContent.append("<h1>Test Report</h1>");
            reportContent.append("<table border='1'><tr><th>Action</th><th>Screenshot</th></tr>");
        } catch (Exception e) {
            System.out.println("Error initializing WebDriver: " + e.getMessage());
            throw e;
        }
    }

    @Test
    public void executeTestSteps() {
        try {
            // Open the website
            driver.get("https://practicetestautomation.com/");
            takeScreenshot("launch_page.png");
            logAction("Successfully launched the page", "launch_page.png");

            // Click on 'Practice' link
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement practiceLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Practice']")));
            practiceLink.click();
            takeScreenshot("practice_page.png");
            logAction("Clicked the 'Practice' link", "practice_page.png");

            // Click on 'Test Login Page' link
            WebElement loginLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Test Login Page']")));
            loginLink.click();
            takeScreenshot("login_page.png");
            logAction("Clicked the 'Test Login' link", "login_page.png");

            // Type in the username
            WebElement usernameField = driver.findElement(By.xpath("//input[@id='username']"));
            usernameField.sendKeys("student");
            takeScreenshot("typed_username.png");
            logAction("Typed 'student' in the username field", "typed_username.png");

            // Type in the password
            WebElement passwordField = driver.findElement(By.xpath("//input[@id='password']"));
            passwordField.sendKeys("Password123");
            takeScreenshot("typed_password.png");
            logAction("Typed password", "typed_password.png");

            // Click on the login button
            WebElement loginButton = driver.findElement(By.xpath("//*[@id=\"submit\"]"));
            loginButton.click();
            takeScreenshot("after_login.png");
            logAction("Clicked the login button", "after_login.png");

            // Optionally, you can assert the successful login
            String pageTitle = driver.getTitle();
            System.out.println("Page Title: " + pageTitle);
            Assert.assertTrue(pageTitle.contains("Logged In"), "Page title does not contain 'Logged In'");

        } catch (Exception e) {
            e.printStackTrace();
            logAction("Test failed", null);
        }
    }

    @AfterMethod
    public void tearDown() {
        try {
            // Close the browser
            if (driver != null) {
                driver.quit();
            }

            // Finalize the HTML report by closing the table and body
            reportContent.append("</table></body></html>");
            
            // Generate the report file name using current date and time
            String reportFileName = "TestReport_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss")) + ".html";
            String reportFilePath = REPORT_FOLDER + reportFileName;

            // Write the report to the file
            try (FileWriter writer = new FileWriter(reportFilePath)) {
                writer.write(reportContent.toString());
            }

            System.out.println("HTML Report generated at: " + reportFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to capture screenshots and save them with a timestamped name
    private void takeScreenshot(String screenshotName) {
        try {
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            // Save the screenshot with a timestamp
            String currentDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            String screenshotPath = SCREENSHOT_FOLDER + screenshotName.replace(".png", "_" + currentDateTime + ".png");

            // Copy the screenshot to the defined location
            FileHandler.copy(screenshot, new File(screenshotPath));
            System.out.println("Screenshot saved as: " + screenshotName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Log actions into the HTML report
    private void logAction(String actionDescription, String screenshotFile) {
        reportContent.append("<tr>");
        reportContent.append("<td>" + actionDescription + "</td>");
        if (screenshotFile != null) {
            reportContent.append("<td><img src='screenshots/" + screenshotFile + "' width='400'></td>");
        } else {
            reportContent.append("<td>None</td>");
        }
        reportContent.append("</tr>");
    }
}


package seleniumprojects;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class findingallmenus {
    public static void main(String[] args) {
        try {
            // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

            WebDriver driver = new ChromeDriver();

            // driver.manage().window().maximize();
            driver.get("https://demowebshop.tricentis.com/");
            
            List<WebElement> menuLinks = driver.findElements(By.tagName("a"));
            
            System.out.println("Menu Links on the page: ");
            for (WebElement link : menuLinks) {
                System.out.println(link.getText() + " - " + link.getAttribute("href"));
            }
            driver.quit();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

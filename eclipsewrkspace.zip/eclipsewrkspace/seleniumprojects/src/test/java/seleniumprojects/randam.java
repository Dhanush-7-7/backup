package seleniumprojects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class randam {

    public static void main(String[] args) throws InterruptedException {

        EdgeOptions options = new EdgeOptions();
       options.addArguments("--start-maximized"); 
    
        
        WebDriver driver = new EdgeDriver(options);

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        try {
            driver.get("https://demowebshop.tricentis.com/");
            System.out.println("Navigated to Demo Web Shop");

            WebElement registerButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Register")));
            registerButton.click();
            System.out.println("Navigated to Registration Page");

            Thread.sleep(1000);

            WebElement maleGenderRadioButton = driver.findElement(By.id("gender-male"));
            maleGenderRadioButton.click();

            WebElement firstNameField = driver.findElement(By.id("FirstName"));
            firstNameField.sendKeys("John");

            WebElement lastNameField = driver.findElement(By.id("LastName"));
            lastNameField.sendKeys("Doe");

            WebElement emailField = driver.findElement(By.id("Email"));
            emailField.sendKeys("john.doe" + System.currentTimeMillis() + "@example.com");

            WebElement passwordField = driver.findElement(By.id("Password"));
            passwordField.sendKeys("Password123!");

            WebElement confirmPasswordField = driver.findElement(By.id("ConfirmPassword"));
            confirmPasswordField.sendKeys("Password123!");

            Thread.sleep(1000);  

            WebElement registerSubmitButton = driver.findElement(By.id("register-button"));
            registerSubmitButton.click();
            System.out.println("Registration Form Submitted");

            Thread.sleep(2000);  

            WebElement registrationSuccessMessage = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.className("result"))
            );

            if (registrationSuccessMessage.isDisplayed() && registrationSuccessMessage.getText().contains("Your registration completed")) {
                System.out.println("Registration successful!");
            } else {
                System.out.println("Registration failed!");
            }

        } catch (Exception e) {
            e.printStackTrace();  
        } finally {
            driver.quit();
        }
    }
}

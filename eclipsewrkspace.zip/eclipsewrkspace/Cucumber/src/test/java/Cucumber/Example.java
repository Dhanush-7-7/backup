package Cucumber;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

import static org.junit.Assert.*;

public class Example {

    WebDriver driver;

    @Given("I navigate to the registration page")
    public void navigateToRegistrationPage() {
        ChromeOptions options = new ChromeOptions();
        driver = new ChromeDriver(options);
        driver.get("https://demowebshop.tricentis.com/register");
    }

    // Step to fill in the registration form
    @When("I fill in the registration form with valid details")
    public void fillRegistrationForm() {
        // Select Gender (Radio button using XPath)
        WebElement genderMale = driver.findElement(By.xpath("//input[@id='gender-male']"));
        genderMale.click(); // Assuming Male is selected

        // Fill out the registration form
        WebElement firstName = driver.findElement(By.id("FirstName"));
        firstName.sendKeys("John");

        WebElement lastName = driver.findElement(By.id("LastName"));
        lastName.sendKeys("Doe");

        WebElement email = driver.findElement(By.id("Email"));
        email.sendKeys("johnw@example.com");

        WebElement password = driver.findElement(By.id("Password"));
        password.sendKeys("Password123");

        WebElement confirmPassword = driver.findElement(By.id("ConfirmPassword"));
        confirmPassword.sendKeys("Password123");
    }

    // Step to submit the registration form
    @When("I submit the registration form")
    public void submitRegistrationForm() {
        WebElement registerButton = driver.findElement(By.id("register-button"));
        registerButton.click();
    }

    // Step to verify that the registration was successful
    @Then("I should see a confirmation message")
    public void verifyConfirmationMessage() {
        // Wait for the confirmation message to be visible
        WebDriverWait wait = new WebDriverWait(driver, 10);
        WebElement confirmationMessage = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("result"))
        );

        // Verify if the confirmation message is displayed
        assertTrue("The registration confirmation message was not displayed", confirmationMessage.isDisplayed());
        driver.quit();
    }
}

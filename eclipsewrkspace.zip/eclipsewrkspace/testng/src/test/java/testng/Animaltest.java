package testng;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Animaltest {

    @Test
    public void testDogSound() {
        String dogSound = "Shiro says Woof!";
        System.out.println(dogSound);
        Assert.assertTrue(dogSound.contains("Woof!"), "Dog's sound is incorrect.");
    }

    @Test
    public void testCatSound() {
        String catSound = "Tiger says Meow!";
        System.out.println(catSound);
        Assert.assertTrue(catSound.contains("Meow!"), "Cat's sound is incorrect.");
    }

    @Test
    public void testAnimalName() {
        String dogName = "Shiro";
        String catName = "Tiger";

        Assert.assertEquals(dogName, "Shiro", "The dog's name should be Shiro");
        Assert.assertEquals(catName, "Tiger", "The cat's name should be Tiger");
        
    }
}

package testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Practice {
    WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Set up WebDriver (ensure chromedriver is correctly set up on your system)
        driver = new ChromeDriver();
    }

    @Test
    public void launchAmazon() {
        // Launch Amazon
        driver.get("https://www.amazon.in/");

        // Test Case 1: Verify the page title
        String pageTitle = driver.getTitle();
        Assert.assertTrue(pageTitle.contains("Amazon"), "Amazon page title doesn't contain 'Amazon'");

        System.out.println("Amazon homepage launched and title verified.");
    }

    @Test
    public void verifySearchBoxPresence() {
        // Verify the search bar is present on Amazon using XPath
        WebElement searchBox = driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));
        Assert.assertTrue(searchBox.isDisplayed(), "Search bar is not displayed.");
        System.out.println("Search bar is present on the Amazon homepage.");
    }

    @Test
    public void verifySignInButton() {
        // Verify the 'Sign in' button is present using XPath
        WebElement signInButton = driver.findElement(By.xpath("//a[@id='nav-link-accountList']"));
        Assert.assertTrue(signInButton.isDisplayed(), "'Sign in' button is not displayed.");
        System.out.println("'Sign in' button is present on the Amazon homepage.");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();  // Close the browser after tests are done
        }
    }
}

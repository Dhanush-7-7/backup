package testng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Launchurl {
    WebDriver test;

    @BeforeTest
    public void setUp() {
    	
    	test = new ChromeDriver();
    	test.get("https://demowebshop.tricentis.com");
    }

    @Test
    public void testUrlLaunch() {
        String title = test.getTitle();
        System.out.println("Page Title: " + title);
        
        test.quit();
        
    }
}


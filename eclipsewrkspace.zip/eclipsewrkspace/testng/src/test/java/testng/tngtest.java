package testng;

public class tngtest {
	    public int add(int a, int b) {
	        return a + b;
	    }
	}



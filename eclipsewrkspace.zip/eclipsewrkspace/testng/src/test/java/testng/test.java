package testng;

import org.testng.Assert;
import org.testng.annotations.Test;

public class test {
	
    tngtest addition = new tngtest();

    @Test
    public void testAddition() {
        int result = addition.add(5, 3);
        Assert.assertEquals(result, 8, "Addition result is incorrect!");
    }

    @Test
    public void testAdditionNegative() {
        int result = addition.add(-5, -3);
        Assert.assertEquals(result, -8, "Addition with negative numbers is incorrect!");
    }
    
    @Test
    public void testAdditionZero() {
        int result = addition.add(0, 5);
        Assert.assertEquals(result, 5, "Addition with zero is incorrect!");
    }
}

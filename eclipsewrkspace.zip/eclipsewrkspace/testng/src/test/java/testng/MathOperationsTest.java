package testng;
	
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

public class MathOperationsTest {

   MathOperations mathOperations = new MathOperations();

    @Test
    public void testSubtraction() {
        int result = mathOperations.subtract(10, 5);
        Assert.assertEquals(result, 5, "Subtraction result is incorrect!");
    }

    @Test
    public void testSubtractionNegative() {
        int result = mathOperations.subtract(-10, -5);
        Assert.assertEquals(result, -5, "Subtraction with negative numbers is incorrect!");
    }

    @Test(enabled = false) 
    public void testSubtractionSkipped() {
        int result = mathOperations.subtract(10, 5);
        Assert.assertEquals(result, 0, "This test is skipped, and will not run!");
    }

    @Test
    public void testSubtractionConditionallySkipped() {
        boolean shouldSkip = true; 
        
        if (shouldSkip) {
            throw new SkipException("Skipping this test due to a condition.");
        }

        int result = mathOperations.subtract(20, 10);
        Assert.assertEquals(result, 10, "Subtraction result is incorrect!");
    }
}


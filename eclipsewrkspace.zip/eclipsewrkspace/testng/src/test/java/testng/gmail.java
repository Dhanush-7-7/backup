package testng;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class gmail {

   @DataProvider(name = "urlProvider")
   public Object[][] provideUrls() {
       return new Object[][] {
           { "https://demowebshop.tricentis.com/" },  
           { "https://gmail.com/" },                
       };
   }

   @Test(dataProvider = "urlProvider")
   public void testUrls(String url) {
       System.out.println("Testing URL: " + url);
   }
}

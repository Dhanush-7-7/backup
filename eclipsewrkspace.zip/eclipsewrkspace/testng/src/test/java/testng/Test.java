package testng;

import java.io.*;
import java.nio.file.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Test {

    WebDriver driver;
    
    private static final String SCREENSHOT_FOLDER = "/home/zadmin/screenshot/";
    private static final String REPORT_FOLDER = "/home/zadmin/screenshot/";

    private StringBuilder reportContent = new StringBuilder();

    @BeforeMethod
    public void setUp() throws Exception {
        try {
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            
            // Create directories if they don't exist
            Files.createDirectories(Paths.get(SCREENSHOT_FOLDER));
            Files.createDirectories(Paths.get(REPORT_FOLDER));

            reportContent.append("<html><head><title>Test Automation Report</title></head><body>");
            reportContent.append("<h1>Test Report</h1>");
            reportContent.append("<table border='1'><tr><th>Action</th><th>Screenshot</th></tr>");
        } catch (Exception e) {
            System.out.println("Error initializing WebDriver: " + e.getMessage());
            throw e;
        }
    }

    @BeforeTest
    public void executeTestSteps() {
        try {
            driver.get("https://practicetestautomation.com/");
            String screenshotName = "launch_page.png";
            takeScreenshot(screenshotName);
            logAction("Successfully launched the page", screenshotName);

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement practiceLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Practice']")));
            practiceLink.click();
            screenshotName = "practice_page.png";
            takeScreenshot(screenshotName);
            logAction("Clicked the 'Practice' link", screenshotName);

            WebElement loginLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Test Login Page']")));
            loginLink.click();
            screenshotName = "login_page.png";
            takeScreenshot(screenshotName);
            logAction("Clicked the 'Test Login' link", screenshotName);

            WebElement usernameField = driver.findElement(By.xpath("//input[@id='username']"));
            usernameField.sendKeys("student");
            screenshotName = "typed_username.png";
            takeScreenshot(screenshotName);
            logAction("Typed 'student' in the username field", screenshotName);

            WebElement passwordField = driver.findElement(By.xpath("//input[@id='password']"));
            passwordField.sendKeys("Password123");
            screenshotName = "typed_password.png";
            takeScreenshot(screenshotName);
            logAction("Typed password", screenshotName);

            WebElement loginButton = driver.findElement(By.xpath("//*[@id='submit']"));
            loginButton.click();
            screenshotName = "after_login.png";
            takeScreenshot(screenshotName);
            logAction("Clicked the login button", screenshotName);

            String pageTitle = driver.getTitle();
            System.out.println("Page Title: " + pageTitle);
            Assert.assertTrue(pageTitle.contains("Logged In"), "Page title does not contain 'Logged In'");

        } catch (Exception e) {
            e.printStackTrace();
            logAction("Test failed", null);
        }
    }

    @AfterMethod
    public void tearDown() {
        try {
            if (driver != null) {
                driver.quit();
            }

            reportContent.append("</table></body></html>");
            
            // Generate the report with a timestamped name
            String reportFileName = "TestReport_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss")) + ".html";
            String reportFilePath = REPORT_FOLDER + reportFileName;

            // Create the HTML report
            try (FileWriter writer = new FileWriter(reportFilePath)) {
                writer.write(reportContent.toString());
            }

            System.out.println("HTML Report generated at: " + reportFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void takeScreenshot(String screenshotName) {
        try {
            // Ensure the screenshots directory exists
            Path screenshotPath = Paths.get(SCREENSHOT_FOLDER);
            if (!Files.exists(screenshotPath)) {
                Files.createDirectories(screenshotPath); // Create the directory if it doesn't exist
                System.out.println("Directory created: " + screenshotPath.toString());
            } else {
                System.out.println("Directory already exists: " + screenshotPath.toString());
            }

            // Capture the screenshot
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            // Adding timestamp to the screenshot name
            String currentDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            String screenshotFileName = screenshotName.replace(".png", "_" + currentDateTime + ".png");
            String screenshotFilePath = screenshotPath + "/" + screenshotFileName;

            // Save the screenshot
            File destinationFile = new File(screenshotFilePath);
            FileHandler.copy(screenshot, destinationFile);

            System.out.println("Screenshot saved as: " + screenshotFilePath);
        } catch (IOException e) {
            System.out.println("Error capturing screenshot: " + e.getMessage());
            e.printStackTrace();
        }
    }


    private void logAction(String actionDescription, String screenshotFile) {
        reportContent.append("<tr>");
        reportContent.append("<td>" + actionDescription + "</td>");
        if (screenshotFile != null) {
            // Adjust the image path to match the file location in the report folder
            String imagePath = "screenshots/" + screenshotFile;
            reportContent.append("<td><img src='" + imagePath + "' width='400'></td>");
        } else {
            reportContent.append("<td>None</td>");
        }
        reportContent.append("</tr>");
    }
}

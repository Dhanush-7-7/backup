package seleniumprojects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class chatgpt{

    public static void main(String[] args) {

        // Set up the ChromeDriver (make sure the path to chromedriver is correct)
       // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        WebDriver driver = new ChromeDriver();

        try {
            // Open ChatGPT's URL
            driver.get("https://chat.openai.com/");

            // Create an instance of WebDriverWait (with a 10-second timeout)
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            // Wait for the input field to be visible (using XPath)
            WebElement inputBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea")));

            // Enter some text into the input box
            inputBox.sendKeys("Hello, ChatGPT!");

            // Submit the message using the Enter key
         //   inputBox.sendKeys(Keys.RETURN);

            // Optionally, wait for the response to appear or for another condition to be met
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(), 'ChatGPT')]"))); // Just an example condition

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Quit the driver (close the browser)
            driver.quit();
        }
    }
}

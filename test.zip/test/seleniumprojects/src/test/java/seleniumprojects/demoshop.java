package seleniumprojects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class demoshop {

    public static void main(String[] args) {
        
        // Set up WebDriver for Chrome (Ensure the correct path to chromedriver is set)
        // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");  // Update this path
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");  // Maximize the browser window
        
        // Initialize WebDriver
        WebDriver driver = new ChromeDriver(options);

        // Set an implicit wait (if necessary, for global element search)
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // Create an explicit wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        try {
            // Test Case 1: Open the Demo Web Shop Homepage
            driver.get("https://demowebshop.tricentis.com/");
            System.out.println("Test Case 1: Open the Homepage - Passed");

            // Test Case 2: Verify the presence of the "Register" button
            WebElement registerButton = driver.findElement(By.linkText("Register"));
            if (registerButton.isDisplayed()) {
                System.out.println("Test Case 2: 'Register' button is displayed - Passed");
            }

            // Test Case 3: Click on the "Register" button and verify redirection to the registration page
            registerButton.click();
            if (driver.getCurrentUrl().contains("register")) {
                System.out.println("Test Case 3: Register button click - Passed");
            }

            // Test Case 4: Go back to the homepage
            driver.navigate().back();
            if (driver.getCurrentUrl().equals("https://demowebshop.tricentis.com/")) {
                System.out.println("Test Case 4: Navigation back to homepage - Passed");
            }

            // Test Case 5: Verify the "Log in" button is present on the homepage
            WebElement loginButton = driver.findElement(By.linkText("Log in"));
            if (loginButton.isDisplayed()) {
                System.out.println("Test Case 5: 'Log in' button is displayed - Passed");
            }

            // Test Case 6: Search for a product (e.g., "Apple MacBook Pro 13-inch")
            WebElement searchBox = driver.findElement(By.id("small-searchterms"));
            searchBox.sendKeys("Apple MacBook Pro 13-inch");
            WebElement searchButton = driver.findElement(By.cssSelector("input[type='submit'][class='button-1 search-box-button']"));
            searchButton.click();

            // Wait for the search results container to load (instead of waiting for a single product)
            WebElement searchResults = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".search-results")));
            if (searchResults.isDisplayed()) {
                System.out.println("Test Case 6: Product search for 'Apple MacBook Pro 13-inch' - Passed");

                // Attempt to find the product using partial link text (in case the product name is slightly different)
                WebElement productTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText("Apple MacBook Pro")));
                if (productTitle.isDisplayed()) {
                    productTitle.click();
                    System.out.println("Test Case 6: Clicked on the product 'Apple MacBook Pro 13-inch' - Passed");
                }
            } else {
                System.out.println("Search results not displayed or product not found.");
            }

            // Test Case 7: Add product to the shopping cart
            WebElement addToCartButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("add-to-cart-button-4")));
            addToCartButton.click();
            WebElement cartButton = driver.findElement(By.className("cart-label"));
            if (cartButton.isDisplayed()) {
                System.out.println("Test Case 7: Product added to the cart - Passed");
            }

            // Test Case 8: Proceed to checkout
            cartButton.click();
            WebElement checkoutButton = driver.findElement(By.className("checkout"));
            checkoutButton.click();
            if (driver.getCurrentUrl().contains("checkout")) {
                System.out.println("Test Case 8: Proceed to checkout - Passed");
            }

            // Test Case 9: Verify the presence of 'Welcome, Please Sign In' text on the checkout page
            WebElement signInText = driver.findElement(By.cssSelector(".page-title"));
            if (signInText.getText().contains("Welcome, Please Sign In")) {
                System.out.println("Test Case 9: 'Welcome, Please Sign In' text is present - Passed");
            }

            // Test Case 10: Sign out from the website
            WebElement logoutButton = driver.findElement(By.linkText("Log out"));
            logoutButton.click();
            if (driver.getCurrentUrl().equals("https://demowebshop.tricentis.com/")) {
                System.out.println("Test Case 10: Logout functionality - Passed");
            }

        } catch (Exception e) {
            e.printStackTrace();  // For debugging purposes if any exception occurs during the test
        } finally {
            // Close the browser after tests
            driver.quit();
        }
    }
}

package seleniumprojects;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Launchwebsite {
	public static void main(String[] args) {
	
		//System.setProperty("webdriver.chrome.driver","/home/zadmin/Desktop/selenium-java-4.28.1/chromedriver.exe");
		
	WebDriver driver =new ChromeDriver();
	
	//String launch= driver.get("https://www.google.com");
	
	driver.manage().window().maximize();
	
	driver.get("https://demowebshop.tricentis.com/");
	String title= driver.getTitle();
	System.out.println("Page Title" + title);
	
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));	
	WebElement booksLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='/books']")));
	
	booksLink.click();
	
	System.out.println("Clicked on the 'Books' link.");
	
	
	//WebElement computersLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='/computers']")));

	
	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@href='/computers']")));
	List<WebElement> allLinks = driver.findElements(By.xpath("//a"));
	
	System.out.println("List of links on the page :");
	for(WebElement link : allLinks) {
		String linkUrl = link.getAttribute("href");
		if(linkUrl != null) {
			System.out.println("linkUrl");
		}
	}
	
	
	
	driver.quit();
	
	}
}


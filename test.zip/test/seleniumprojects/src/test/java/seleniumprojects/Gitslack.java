package seleniumprojects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class Gitslack {

    public static void main(String[] args) {
                // System.setProperty("webdriver.chrome.driver", );

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");

        WebDriver driver = new ChromeDriver(options);

        try {
            driver.get("https://gitlab.stackroute.in/users/sign_in");

            WebElement emailField = driver.findElement(By.id("user_login"));
            emailField.sendKeys("Dhanush.palanisamy"); 

            WebElement passwordField = driver.findElement(By.id("user_password"));
            passwordField.sendKeys("Itc@1234"); 

            WebElement loginButton = driver.findElement(By.name("commit"));
            loginButton.click();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement loggedInElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("user_profile")));

            if (loggedInElement != null) {
                System.out.println("Login Successful!");
            } else {
                System.out.println("Login Failed!");
            }
        } catch (Exception e) {
            System.out.println("Test Failed: " + e.getMessage());
        } finally {
            driver.quit();
        }
    }
}

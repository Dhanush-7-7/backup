package seleniumprojects;

//import java.io.File;
//
//import org.apache.logging.log4j.core.util.FileUtils;
import org.openqa.selenium.By;
//import org.openqa.selenium.OutputType;
//import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


//import java.io.IOException;
//import org.apache.commons.io.FileUtils;

public class PracticeTestLogin {
    public static void main(String[] args) {
      

        WebDriver driver = new ChromeDriver();

        driver.manage().window().maximize();
        
        
//       / TakesScreenshot screenshot = (TakesScreenshot) driver;
//        File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
//        
//        File destFile = new File("/path/to/screenshot.png");
//        
//        FileUtils.copyFile(srcFile, destFile);
//        
//        System.out.println("Screenshot saved successfully!");

        
        

        driver.get("https://practicetestautomation.com/");
        System.out.println(" successfully launch the driver");

        
        WebElement practiceLink = driver.findElement(By.xpath("//a[text()='Practice']"));
        practiceLink.click();
        System.out.println("clicked browser");


        
       WebElement loginLink = driver.findElement(By.xpath("//*[@id='loop-container']/div/article/div[2]/div[1]/div[1]/p/a"));
        loginLink.click();
        System.out.println("clicked the test login");


        WebElement usernameField = driver.findElement(By.xpath("//input[@id='username']")); 
        usernameField.sendKeys("student");
        System.out.println("typed student in the input field");


        WebElement passwordField = driver.findElement(By.xpath("//input[@id='password']")); 
        passwordField.sendKeys("Password123");
        System.out.println("typing password");


        WebElement loginButton = driver.findElement(By.xpath("//*[@id=\"submit\"]")); 
        System.out.println("login successfully");
        loginButton.click();


       // driver.quit();
        System.out.println("close the driver ");

    }
}

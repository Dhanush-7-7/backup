package seleniumprojects;
	
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class snap {
    public static void main(String[] args) {
      
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-notifications");

        WebDriver driver = new ChromeDriver(options);

        try {
            driver.get("https://accounts.snapchat.com/");

            Thread.sleep(2000);

            WebElement emailField = driver.findElement(By.name("username"));
            emailField.sendKeys("your_email@example.com");

            WebElement passwordField = driver.findElement(By.name("password"));
            passwordField.sendKeys("your_password");

            WebElement loginButton = driver.findElement(By.xpath("//button[@type='submit']"));
            loginButton.click();

            Thread.sleep(5000);

            if (driver.getCurrentUrl().contains("feed")) {
                System.out.println("Login Successful!");
            } else {
                System.out.println("Login Failed!");
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}

package seleniumprojects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;

public class facebooklaunch {

    public static void main(String[] args) {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized"); 
        WebDriver driver = new ChromeDriver(options);

        try {
            driver.get("https://www.facebook.com");
            WebElement emailField = driver.findElement(By.id("email"));
            emailField.sendKeys("your-email-or-phone");
            WebElement passwordField = driver.findElement(By.id("pass"));
            passwordField.sendKeys("your-password");
            WebElement loginButton = driver.findElement(By.name("login"));
            loginButton.click();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
         //   driver.quit();
        }
    }
}

package testng;

public class MathOperations {
	public int subtract(int a, int b) {
        return a-b;
        
    }
}



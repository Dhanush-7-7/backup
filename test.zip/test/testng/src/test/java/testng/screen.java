package testng;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class screen {

    private WebDriver driver;
    private String screenshotDirectory = "/home/zadmin/screenshot/screenshots/";  
    private String reportDirectory = "/home/zadmin/screenshot/reports/";  
    private FileWriter reportWriter;

    @BeforeClass
    public void setUp() throws IOException {
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        new File(screenshotDirectory).mkdirs();
        new File(reportDirectory).mkdirs();

        reportWriter = new FileWriter(reportDirectory + "test_report.html");
        reportWriter.write("<html>\n<head>\n<title>Test Automation Report</title>\n</head>\n<body>\n");
        reportWriter.write("<h1>Test Automation Report</h1>\n");
        reportWriter.write("<table border='1' cellpadding='10' cellspacing='0'>\n");
        reportWriter.write("<tr><th>Screenshot Name</th><th>Stage</th><th>Screenshot</th><th>Timestamp (IST)</th></tr>\n");
    }

    @Test(priority = 1)
    public void launchPageAndTakeScreenshot() throws IOException {
        driver.get("https://practicetestautomation.com/");
        String screenshotName = "launch_page.png";
        takeScreenshot(driver, screenshotDirectory, screenshotName);
        String timestamp = getISTTime();
        
        reportWriter.write("<tr>\n");
        reportWriter.write("<td>" + screenshotName + "</td>\n");
        reportWriter.write("<td>Launched the page and took screenshot</td>\n");
        reportWriter.write("<td><img src='../screenshots/" + screenshotName + "' width='300' /></td>\n");
        reportWriter.write("<td>" + timestamp + "</td>\n"); 
        reportWriter.write("</tr>\n");
    }

    @Test(priority = 2)
    public void clickPracticeLinkAndTakeScreenshot() throws IOException {
        WebElement practiceLink = driver.findElement(By.xpath("//a[text()='Practice']"));
        practiceLink.click();
        String screenshotName = "practice_page.png";
        takeScreenshot(driver, screenshotDirectory, screenshotName);
        String timestamp = getISTTime();

        reportWriter.write("<tr>\n");
        reportWriter.write("<td>" + screenshotName + "</td>\n");
        reportWriter.write("<td>Clicked the 'Practice' link and took screenshot</td>\n");
        reportWriter.write("<td><img src='../screenshots/" + screenshotName + "' width='300' /></td>\n");
        reportWriter.write("<td>" + timestamp + "</td>\n"); 
        reportWriter.write("</tr>\n");
    }

    @Test(priority = 3)
    public void clickLoginLinkAndTakeScreenshot() throws IOException {
        WebElement loginLink = driver.findElement(By.xpath("//a[text()='Test Login Page']"));
        loginLink.click();
        String screenshotName = "login_page.png";
        takeScreenshot(driver, screenshotDirectory, screenshotName);
        String timestamp = getISTTime();

        reportWriter.write("<tr>\n");
        reportWriter.write("<td>" + screenshotName + "</td>\n");
        reportWriter.write("<td>Clicked the 'Test Login' link and took screenshot</td>\n");
        reportWriter.write("<td><img src='../screenshots/" + screenshotName + "' width='300' /></td>\n");
        reportWriter.write("<td>" + timestamp + "</td>\n"); 
        reportWriter.write("</tr>\n");
    }

    @Test(priority = 4)
    public void typeUsernameAndTakeScreenshot() throws IOException {
        WebElement usernameField = driver.findElement(By.xpath("//input[@id='username']"));
        usernameField.sendKeys("student");
        String screenshotName = "typed_username.png";
        takeScreenshot(driver, screenshotDirectory, screenshotName);
        String timestamp = getISTTime();

        reportWriter.write("<tr>\n");
        reportWriter.write("<td>" + screenshotName + "</td>\n");
        reportWriter.write("<td>Typed 'student' in the username field and took screenshot</td>\n");
        reportWriter.write("<td><img src='../screenshots/" + screenshotName + "' width='300' /></td>\n");
        reportWriter.write("<td>" + timestamp + "</td>\n"); 
        reportWriter.write("</tr>\n");
    }

    @Test(priority = 5)
    public void typePasswordAndTakeScreenshot() throws IOException {
        WebElement passwordField = driver.findElement(By.xpath("//input[@id='password']"));
        passwordField.sendKeys("Password123");
        String screenshotName = "typed_password.png";
        takeScreenshot(driver, screenshotDirectory, screenshotName);
        String timestamp = getISTTime();

        reportWriter.write("<tr>\n");
        reportWriter.write("<td>" + screenshotName + "</td>\n");
        reportWriter.write("<td>Typed password and took screenshot</td>\n");
        reportWriter.write("<td><img src='../screenshots/" + screenshotName + "' width='300' /></td>\n");
        reportWriter.write("<td>" + timestamp + "</td>\n"); 
        reportWriter.write("</tr>\n");
    }

    @Test(priority = 6)
    public void clickLoginButtonAndTakeScreenshot() throws IOException {
        WebElement loginButton = driver.findElement(By.xpath("//*[@id='submit']"));
        loginButton.click();
        String screenshotName = "after_login.png";
        takeScreenshot(driver, screenshotDirectory, screenshotName);
        String timestamp = getISTTime();

        reportWriter.write("<tr>\n");
        reportWriter.write("<td>" + screenshotName + "</td>\n");
        reportWriter.write("<td>Clicked the login button and took screenshot</td>\n");
        reportWriter.write("<td><img src='../screenshots/" + screenshotName + "' width='300' /></td>\n");
        reportWriter.write("<td>" + timestamp + "</td>\n"); 
        reportWriter.write("</tr>\n");
    }

    @AfterClass
    public void tearDown() throws IOException {
        driver.quit();
        reportWriter.write("</table>\n");
        reportWriter.write("<p>Driver closed.</p>\n");
        reportWriter.write("</body>\n</html>\n");
        reportWriter.close();
    }

    private void takeScreenshot(WebDriver driver, String screenshotDirectory, String screenshotName) {
        TakesScreenshot screenshot = (TakesScreenshot) driver;
        File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
        File destFile = new File(screenshotDirectory + screenshotName);
        try {
            FileUtils.copyFile(srcFile, destFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getISTTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        return sdf.format(new Date());
    }
}

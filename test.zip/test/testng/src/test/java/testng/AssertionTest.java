package testng;

import org.testng.Assert;
import org.testng.annotations.Test;

public class AssertionTest {

    @Test
    public void testEquals() {
        String expected = "Hello";
        String actual = "Hello";
        
        
        
        Assert.assertEquals(actual, expected, "Strings are not equal!");
    }

    @Test
    public void testNotEquals() {
        int expected = 10;
        int actual = 100;

        Assert.assertNotEquals(actual, expected, "Values are equal!");
        Assert.assertNotEquals(expected, actual,"values are equal!");     
    }
}

/*package testng;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class FindingElementsTestNG {

    WebDriver driver;
    WebDriverWait wait;

    @BeforeClass
    public void setUp() {
    	
        driver = new ChromeDriver();
       
        
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        
        driver.manage().window().maximize();
    }

    @Test
    (priority = 1)
    public void navigateToDemoWebShop() {
        driver.get("https://demowebshop.tricentis.com/");
    }

    @Test
    (priority = 2)
    public void clickBooksCategory() {
        WebElement booksCategory = driver.findElement(By.xpath("//a[text()='Books']"));
        booksCategory.click();
    }

    @Test
    (priority = 3)
    public void printProductNamesOnBooksPage() {
        java.util.List<WebElement> productNames = driver.findElements(By.xpath("//h2"));
        for (WebElement product : productNames) {
            System.out.println("Product: " + product.getText());
        }
    }

    @Test
    (priority = 4)
    public void addProductToCart() {
        WebElement addToCartButton = driver.findElement(By.xpath("//input[@value='Add to cart']"));
        addToCartButton.click();

        WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='bar-notification success']")));
        System.out.println("Success Message: " + successMessage.getText());

        Assert.assertTrue(successMessage.isDisplayed(), "Success message is not displayed.");
    }

    @Test(priority = 5)
    public void navigateToShoppingCart() {
        WebElement cartButton = driver.findElement(By.xpath("//a[contains(@href,'/cart')]"));
        cartButton.click();

        WebElement cartTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[text()='Shopping cart']")));
        System.out.println("Cart Title: " + cartTitle.getText());
    }

    @Test(priority = 6)
    public void hoverOverElectronicsCategory() {
        WebElement electronicsCategory = driver.findElement(By.xpath("//a[text()='Electronics']"));
        Actions actions = new Actions(driver);
        actions.moveToElement(electronicsCategory).perform();
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
*/
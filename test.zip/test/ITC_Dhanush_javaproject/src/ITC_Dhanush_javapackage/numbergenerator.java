package ITC_Dhanush_javapackage;

import java.util.Random;

public class numbergenerator {
	public static void main(String[] args) {
		Random random = new Random();
		int randomnumber = random.nextInt(50);
		System.out.println(randomnumber);
		
	}
}

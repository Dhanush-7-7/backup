package ITC_Dhanush_javapackage;

import java.util.*;

public class Division{
	public static void main(String[] args) {
		
		try (Scanner s = new Scanner(System.in)) {
			System.out.println("Enter the numbers:");
			int a = s.nextInt();
			int b = s.nextInt();
			
			int c = a/b;
			
			System.out.println("Division of numbers are :" + c);
		}
	}
}

package ITC_Dhanush_javapackage;
import java.awt.Desktop;
	import java.net.URI;
	
	
public class objcheck {
	public static void main(String[] args) {
	        try {
	            URI uri = new URI("https://www.outlook.com");
	            
	            Desktop desktop = Desktop.getDesktop();
	            
	            desktop.browse(uri);
	            
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}




package ITC_Dhanush_javapackage;
import java.io.*;
public class Filewriter {
    public static void main(String[] args) {
        String filePath = "/home/zadmin/Desktop/test/java.txt"; 
        File file = new File(filePath);
        if (file.exists()) {
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, true))) {
                System.out.println("File exists. Writing to file...");
                bw.write("JDK - gives you everything you need to write and run java code.\n"+ "");
                bw.newLine();  
                
                System.out.println("Text has been written to the file.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("File does not exist.");
        }
    }
}

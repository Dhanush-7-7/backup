package ITC_Dhanush_javapackage;
import java.util.Scanner;


abstract class ATM {
    protected int pin;
    protected double balance;

    public ATM(double initialBalance)
    {
        this.balance = initialBalance;
    }

    public abstract boolean enterPin(int enteredPin);

    public abstract void withdrawMoney(double amount);

    public abstract double checkBalance();
}

class ATMImplementation extends ATM {
    private int pin;

    public ATMImplementation(int pin, double initialBalance) {
        super(initialBalance);
        this.pin = pin;
    }

    @Override
    public boolean enterPin(int enteredPin) {
        return enteredPin == pin;
    }

    @Override
    public void withdrawMoney(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful! You withdrew: $" + amount);
        } else {
            System.out.println("Insufficient balance for withdrawal!");
        }
    }

    @Override
    public double checkBalance() {
        return balance;
    }

    public void withdrawMoney(double amount, double fee) {
        if (amount + fee <= balance) {
            balance -= (amount + fee);
            System.out.println("Withdrawal successful! You withdrew: rs" + amount );
        } else {
            System.out.println("Insufficient balance for withdrawal with fee!");
        }
    }
}

public class atm {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Set your PIN: ");
        int userPin = scanner.nextInt();
        System.out.print("Set your initial balance: ");
        double initialBalance = scanner.nextDouble();

        ATMImplementation atm = new ATMImplementation(userPin, initialBalance);

        System.out.print("Enter your PIN to access the ATM: ");
        int enteredPin = scanner.nextInt();

        if (atm.enterPin(enteredPin)) {
            System.out.println("PIN correct! Welcome to the ATM.");

            boolean sessionActive = true;
            while (sessionActive) {
                System.out.println("\nATM Menu:");
                System.out.println("1. Check Balance");
                System.out.println("2. Withdraw Money");
                System.out.println("3. Exit");
                System.out.print("Choose an option (1/2/3): ");
                int option = scanner.nextInt();

                switch (option) {
                    case 1:
                        System.out.println("Current balance: $" + atm.checkBalance());
                        break;

                    case 2:
                        System.out.print("Enter amount to withdraw: $");
                        double amount = scanner.nextDouble();
                        atm.withdrawMoney(amount);
                        break;

                    case 3:
                        sessionActive = false;
                        System.out.println("Thank you for using the ATM. Goodbye!");
                        break;

                    default:
                        System.out.println("Invalid option! Please choose again.");
                }
            }
        } else {
            System.out.println("Incorrect PIN! Access denied.");
        }

        scanner.close();
    }
}

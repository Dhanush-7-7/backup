package ITC_Dhanush_javapackage;

public class defcons {
	public class amazon{
		String products;
		int price;
		

		
		public amazon() {
			products = "Oppo mobile";
			price = 15000;
			
			System.out.println("Default constructor called");
			
			
			
		}
		
		public void displayInfo() {
		System.out.println("products :" +products + ", price :" + price);
		}
		
		public static void main(String[] args) {
			
			defcons example = new defcons();
			amazon mobile = example.new amazon();
			
			mobile.displayInfo();
			
			
		}
		
		
	}
}

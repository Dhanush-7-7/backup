package ITC_Dhanush_javapackage;

import java.util.ArrayList;
import java.util.List;

class Department {
    String departmentName;
    double profit;

    Department(String departmentName, double profit) {
        this.departmentName = departmentName;
        this.profit = profit;
    }

    void displayDepartment() {
        System.out.println("Department: " + departmentName + ", Profit: Rs." + profit);
    }

    double getProfit() {
        return profit;
    }
}

class Employee {
    String employeeName;
    int empid;
    double salary;

    Employee(String employeeName, double salary, int empid) {
        this.employeeName = employeeName;
        this.salary = salary;
        this.empid = empid;
    }

    void displayEmployeeInfo() {
        System.out.println("Employee: " + employeeName + ", Employee ID : " + empid + ", Salary: Rs." + salary);
    }
}

class Company {
    String companyName;
    List<Department> departments;
    Employee employee;

    Company(String companyName, Employee employee) {
        this.companyName = companyName;
        this.departments = new ArrayList<>();
        this.departments = new ArrayList<>();
        this.employee = employee;
        
    }

    void displayCompanyInfo() {
        System.out.println("Company: " + companyName);
        displayAllDepartments();
        employee.displayEmployeeInfo();
    }

    void addDepartment(Department newDepartment) {
        this.departments.add(newDepartment);
        System.out.println("Department added: " + newDepartment.departmentName);
    }

    void displayAllDepartments() {
        System.out.println("Departments in " + companyName + ":");
        if (departments.isEmpty()) {
            System.out.println("No departments available.");
        } else {
            for (Department department : departments) {
                department.displayDepartment();
            }
        }
    }

    double getTotalProfit() {
        double totalProfit = 0;
        for (Department department : departments) {
            totalProfit += department.getProfit();
        }
        return totalProfit;
    }
}

public class company {
    public static void main(String[] args) {
        Employee employee = new Employee("Pranesh", 250000, 101);

        Company company = new Company("ITCI", employee);

        Department dept1 = new Department("Research and Development", 5000000);
        Department dept2 = new Department("Marketing", 3000000);
        company.addDepartment(dept1);
        company.addDepartment(dept2);

        company.displayCompanyInfo();

        double totalProfit = company.getTotalProfit();
        System.out.println("Total Profit of the company: Rs." + totalProfit);
    }
}

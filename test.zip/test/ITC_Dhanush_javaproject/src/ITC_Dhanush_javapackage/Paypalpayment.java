package ITC_Dhanush_javapackage;

class Paypalpayment implements PaymentGateway{
	@Override
	public void Procespayment(double amount) {
		System.out.println("processing paypal payment of "+amount);
	}
	

}

package ITC_Dhanush_javapackage;
import java.util.*;

public class javaalgorithm {
	public static void main(String[] args) {
		
		List<Integer> num=new ArrayList<>(Arrays.asList(5,4,3,1,2));
		num.add(6);
		num.add(7);
		System.out.println("Original List: "+num);
		Collections.sort(num);
		System.out.println("Sorted List: "+num);
		Collections.reverse(num);
		System.out.println("Reversed List: "+num);
		int index=Collections.binarySearch(num,5);
		System.out.println("Index of 4 in sorted list is "+index);
		Collections.shuffle(num);
		System.out.println("Shuffled List: "+num);
		Collections.reverse(num);
		System.out.println("Reversed List: "+num);
			}		
		
	}



package ITC_Dhanush_javapackage;
import java.util.*;

public class javacollectionsimplementation {
	public static void main(String[] args) {
				
		HashMap<Integer, String> map = new HashMap<>();
        map.put(1, "Apple");
        map.put(2, "Banana");
        map.put(3, "Cherry");
        map.put(4, "Date");
        System.out.println("HashMap: " + map);
        String fruit = map.get(2);
        System.out.println("Value for key 2: " + fruit);
        if (map.containsKey(3)) {
            System.out.println("Key 3 is present.");
        }
        map.remove(4);
        System.out.println("HashMap after removing key 4: " + map);
        if (map.containsValue("Apple")) {
            System.out.println("The map contains 'Apple'.");
        }
        System.out.println("\nIterating over the map:");
        for (HashMap.Entry<Integer, String> entry : map.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
        
        }
				
	}


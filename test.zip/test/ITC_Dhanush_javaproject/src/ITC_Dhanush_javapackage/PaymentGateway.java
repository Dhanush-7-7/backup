//define interface for payment gateways
package ITC_Dhanush_javapackage;

interface PaymentGateway{
	void Procespayment(double amount);

}

package ITC_Dhanush_javapackage;

import java.util.*;

public class javacollections1 {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("Java");
        list.add("Python");
        list.add("C++");

        for (String language : list) {
            System.out.println(language);
        }

        Set<Integer> set = new HashSet<>();
        set.add(1);
        set.add(2);
        set.add(3);
        set.add(2);

        System.out.println(set);

        Map<String, Integer> map = new HashMap<>();
        map.put("Java", 10);
        map.put("Python", 9);
        map.put("C++", 8);

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
    }
}

package ITC_Dhanush_javapackage;

public class Maincredit {
	public static void main(String[] args) {
		PaymentGateway payment = new CreditcardPayment();
		payment.Procespayment(100.0);
		
		payment = new Paypalpayment();
		payment.Procespayment(150.0);
	}

}

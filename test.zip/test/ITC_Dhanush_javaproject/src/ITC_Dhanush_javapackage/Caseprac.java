package ITC_Dhanush_javapackage;
import java.util.Scanner;

public class Caseprac {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nWelcome to ITC Hotels");
            System.out.println("1. Meals - 70rs");
            System.out.println("2. Biriyani - 100rs");
            System.out.println("3. tea/coffee - 20/20 ");
            System.out.println("4. Exit");
            System.out.print("Enter your choice (1-4): ");
            
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Selected meals. Price: 70rs");
                    break;

                case 2:
                    System.out.println("Selected biriyani. Price: 100rs");
                    break;
                    
                case 3:
                	System.out.println(" Tea/coffee - 20 rupees each");
                	break;

                case 4:
                    System.out.println("Thank you for visiting!");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
                    continue;
            }

            
            if (choice == 1 || choice == 2) {
                System.out.println(" Get a discount of 10rs!");
            }

            
            if (choice == 2 || choice == 3) {
                System.out.println("Get a discount of 30rs.");
            }
            
           
           
            if (choice == 4) {
                break;
            }
        }
    }
}

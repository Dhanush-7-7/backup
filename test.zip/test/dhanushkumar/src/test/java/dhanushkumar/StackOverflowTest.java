package dhanushkumar;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.apache.commons.io.FileUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;
import java.time.Duration;

public class StackOverflowTest {

    private WebDriver driver;  

    @BeforeClass
    public void setUp() throws IOException {
        driver = new ChromeDriver();
        driver.get("https://stackoverflow.com/");
        driver.manage().window().maximize(); 
        captureScreenshot("setup");
    }

    private void captureScreenshot(String phase) throws IOException {
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshot, new File("/home/zadmin/Desktop/Assignment/" + phase + ".png"));
        System.out.println("Captured screenshot for: " + phase);
    }

    @Test
    public void loginToStackOverflow() throws IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@data-gps-track='login.click']")));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", loginButton);
        captureScreenshot("login_button_clicked");

        WebElement emailInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='email']")));
        emailInput.sendKeys("dhanushkumarpalanisamy@gmail.com");
        captureScreenshot("email_entered");

        WebElement passwordInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='password']")));
        passwordInput.sendKeys("Welcome@760");
        captureScreenshot("password_entered");

        WebElement loginSubmitButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='submit-button']")));
        loginSubmitButton.click();
        captureScreenshot("login_submit_button_clicked");
    }

    @Test(dependsOnMethods = "loginToStackOverflow")
    public void acceptCookies() throws IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement cookieButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Accept')]")));
        cookieButton.click();
        captureScreenshot("cookies_accepted");
    }

    @Test(dependsOnMethods = "acceptCookies")
    public void openCompaniesSection() throws IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement companiesButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Companies']")));
        companiesButton.click();
        captureScreenshot("companies_button_clicked");
    }

    @Test(dependsOnMethods = "openCompaniesSection")
    public void searchForPaylocity() throws IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        
        WebElement searchInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='q']")));
        searchInput.sendKeys("Paylocity");
        captureScreenshot("paylocity_searched");

        WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Search']")));
        searchButton.click();
        captureScreenshot("search_button_clicked");
    }

    @Test(dependsOnMethods = "searchForPaylocity")
    public void filterByPythonTag() throws IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5)); // Increased wait time for stability

        try {
            WebElement tagsButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Tags']")));
            tagsButton.click();
            captureScreenshot("tags_button_clicked");

            WebElement tagFilterInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='tagfilter']")));
            tagFilterInput.sendKeys("python");
            captureScreenshot("tag_filter_python");

            WebElement pythonTag = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='python']")));
            pythonTag.click();
            captureScreenshot("python_tag_clicked");

            WebElement moreDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='s-btn s-btn__muted s-btn__sm s-btn__dropdown']")));
            moreDropdown.click();
            captureScreenshot("more_dropdown_clicked");

            WebElement monthOption = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@href='/questions/tagged/python?tab=Month']")));
            monthOption.click();
            captureScreenshot("month_option_selected");
        } catch (Exception e) {
            System.out.println("Error occurred during filter by python tag: " + e.getMessage());
            captureScreenshot("error_in_filtering_python");
        }
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit(); 
        }
    }
}

package Cucumber;

import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
public class Login {
	WebDriver driver=new ChromeDriver();
	@Given("I navigate to login page")
	public void i_navigate() {
		driver.get("https://demowebshop.tricentis.com/login");
		
	}
	@When("I enter valid username and password")
	public void i_navigate_to_the_login_page()  {
		WebElement username=driver.findElement(By.id("Email"));
		WebElement password=driver.findElement(By.id("Password"));
		username.sendKeys("ananyadiwakar205@gmail.com");
		password.sendKeys("Ananya@21");
		
	}
	@And("I clicked on login")
	public void i_enter_valid_username_and_password() {
		WebElement loginButton=driver.findElement(By.xpath("//input[@value='Log in']"));
		loginButton.click();
	}
	
	@Then("Login succesfull")
	public void i_should_log() {
		String currentUrl=driver.getCurrentUrl();
		Assert.assertTrue(currentUrl.contains("tricentis"),"User is redirected to the login page");
	}
		
	
	
}
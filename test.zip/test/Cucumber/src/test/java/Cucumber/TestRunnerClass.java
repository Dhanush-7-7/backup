package Cucumber;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(
		features={
				"src/test/resources/example.feature",
				"src/test/resources/Login.feature"
		},
		
		glue="Cucumber",
		plugin= {"pretty","html:target/Cucumber-reports"}
		)
public class TestRunnerClass extends AbstractTestNGCucumberTests{
	
}